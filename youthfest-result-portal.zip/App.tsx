
import React, { useState, useEffect, useMemo } from 'react';
import { Layout } from './components/Layout';
import { Dashboard } from './components/Dashboard';
import { ResultsView } from './components/ResultsView';
import { AdminPanel } from './components/AdminPanel';
import { EventResult, HouseStats, POINT_SYSTEM, HouseName } from './types';

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'results' | 'admin'>('dashboard');
  const [results, setResults] = useState<EventResult[]>(() => {
    const saved = localStorage.getItem('youthfest_results');
    return saved ? JSON.parse(saved) : [];
  });

  useEffect(() => {
    localStorage.setItem('youthfest_results', JSON.stringify(results));
  }, [results]);

  const houseStats = useMemo(() => {
    const stats: Record<HouseName, HouseStats> = {
      Alpha: { name: 'Alpha', totalPoints: 0, firstCount: 0, secondCount: 0, thirdCount: 0, color: '#fbbf24' },
      Beta: { name: 'Beta', totalPoints: 0, firstCount: 0, secondCount: 0, thirdCount: 0, color: '#60a5fa' },
      Gamma: { name: 'Gamma', totalPoints: 0, firstCount: 0, secondCount: 0, thirdCount: 0, color: '#f87171' }
    };

    results.forEach(result => {
      stats[result.first].totalPoints += POINT_SYSTEM.FIRST;
      stats[result.first].firstCount += 1;
      
      stats[result.second].totalPoints += POINT_SYSTEM.SECOND;
      stats[result.second].secondCount += 1;
      
      stats[result.third].totalPoints += POINT_SYSTEM.THIRD;
      stats[result.third].thirdCount += 1;
    });

    return Object.values(stats);
  }, [results]);

  const handleAddResult = (newResult: Omit<EventResult, 'id' | 'timestamp'>) => {
    const result: EventResult = {
      ...newResult,
      id: Math.random().toString(36).substr(2, 9),
      timestamp: Date.now()
    };
    setResults(prev => [...prev, result]);
  };

  const handleDeleteResult = (id: string) => {
    setResults(prev => prev.filter(r => r.id !== id));
  };

  const handleReset = () => {
    setResults([]);
  };

  return (
    <Layout activeTab={activeTab} setActiveTab={setActiveTab}>
      {activeTab === 'dashboard' && (
        <Dashboard stats={houseStats} results={results} />
      )}
      {activeTab === 'results' && (
        <ResultsView results={results} />
      )}
      {activeTab === 'admin' && (
        <AdminPanel 
          onAddResult={handleAddResult} 
          onReset={handleReset} 
          results={results}
          onDeleteResult={handleDeleteResult}
        />
      )}
    </Layout>
  );
};

export default App;
