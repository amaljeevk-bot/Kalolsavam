
import { GoogleGenAI } from "@google/genai";
import { EventResult, HouseStats } from "../types";

export const getFestivalCommentary = async (stats: HouseStats[], results: EventResult[]) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const statsString = stats.map(s => 
    `${s.name}: ${s.totalPoints} pts (${s.firstCount} Gold, ${s.secondCount} Silver, ${s.thirdCount} Bronze)`
  ).join(', ');

  const recentEvents = results.slice(-3).map(r => r.eventName).join(', ');

  const prompt = `
    You are an energetic, fun-loving college youth festival announcer. 
    Here is the current leaderboard: ${statsString}.
    Most recent events: ${recentEvents || 'No events yet'}.
    
    Provide a short (max 2 sentences), punchy, and motivating update/shout-out for the houses. 
    Make it sound like it's coming from a stadium loudspeaker.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
    });
    return response.text;
  } catch (error) {
    console.error("Gemini Error:", error);
    return "The competition is heating up! Keep giving your best, everyone!";
  }
};
