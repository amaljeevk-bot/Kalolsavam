
export type HouseName = 'Alpha' | 'Beta' | 'Gamma';

export interface EventResult {
  id: string;
  eventName: string;
  category: 'Stage' | 'Non-Stage' | 'Sports';
  first: HouseName;
  second: HouseName;
  third: HouseName;
  timestamp: number;
}

export interface HouseStats {
  name: HouseName;
  totalPoints: number;
  firstCount: number;
  secondCount: number;
  thirdCount: number;
  color: string;
}

export const POINT_SYSTEM = {
  FIRST: 5,
  SECOND: 3,
  THIRD: 1
};

export const HOUSE_CONFIG: Record<HouseName, { color: string; gradient: string }> = {
  Alpha: { color: '#fbbf24', gradient: 'from-amber-400 to-amber-600' },
  Beta: { color: '#60a5fa', gradient: 'from-blue-400 to-blue-600' },
  Gamma: { color: '#f87171', gradient: 'from-rose-400 to-rose-600' }
};
