
import React, { useState } from 'react';
import { EventResult, HOUSE_CONFIG } from '../types';

interface ResultsViewProps {
  results: EventResult[];
}

export const ResultsView: React.FC<ResultsViewProps> = ({ results }) => {
  const [searchTerm, setSearchTerm] = useState('');

  const filteredResults = results
    .filter(r => r.eventName.toLowerCase().includes(searchTerm.toLowerCase()))
    .sort((a, b) => b.timestamp - a.timestamp);

  if (results.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-center space-y-4">
        <div className="w-20 h-20 bg-slate-900 rounded-full flex items-center justify-center text-slate-700 text-4xl mb-4">
          ?
        </div>
        <h3 className="text-xl font-bold text-slate-300">No results published yet</h3>
        <p className="text-slate-500 max-w-xs">Results will appear here as soon as the judges announce them.</p>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="flex flex-col sm:flex-row justify-between items-center gap-4 mb-8">
        <h2 className="text-2xl font-bold text-white flex items-center gap-3">
          Published Results
          <span className="text-sm font-medium bg-indigo-500/20 text-indigo-400 px-3 py-1 rounded-full border border-indigo-500/20">
            {results.length} Events
          </span>
        </h2>
        <div className="relative w-full sm:w-64">
          <input
            type="text"
            placeholder="Search events..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {filteredResults.map((result) => (
          <div key={result.id} className="glass-morphism rounded-2xl p-5 border border-slate-800 hover:border-slate-700 transition-all">
            <div className="flex justify-between items-start mb-4">
              <div>
                <span className="text-[10px] uppercase font-black tracking-widest text-indigo-400 mb-1 block">
                  {result.category}
                </span>
                <h3 className="text-lg font-bold text-slate-100">{result.eventName}</h3>
              </div>
              <span className="text-xs text-slate-500">
                {new Date(result.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </span>
            </div>

            <div className="grid grid-cols-3 gap-3">
              <div className="bg-slate-900/50 p-3 rounded-xl border border-slate-800/50">
                <div className="text-[10px] uppercase font-bold text-amber-400 mb-2">1st Place</div>
                <div className="flex items-center gap-2">
                  <div className={`w-2 h-2 rounded-full ${HOUSE_CONFIG[result.first].color === '#fbbf24' ? 'bg-amber-400' : HOUSE_CONFIG[result.first].color === '#60a5fa' ? 'bg-blue-400' : 'bg-rose-400'}`}></div>
                  <span className="font-bold text-slate-200">{result.first}</span>
                </div>
              </div>
              <div className="bg-slate-900/50 p-3 rounded-xl border border-slate-800/50">
                <div className="text-[10px] uppercase font-bold text-slate-400 mb-2">2nd Place</div>
                <div className="flex items-center gap-2">
                  <div className={`w-2 h-2 rounded-full ${HOUSE_CONFIG[result.second].color === '#fbbf24' ? 'bg-amber-400' : HOUSE_CONFIG[result.second].color === '#60a5fa' ? 'bg-blue-400' : 'bg-rose-400'}`}></div>
                  <span className="font-bold text-slate-200">{result.second}</span>
                </div>
              </div>
              <div className="bg-slate-900/50 p-3 rounded-xl border border-slate-800/50">
                <div className="text-[10px] uppercase font-bold text-amber-700 mb-2">3rd Place</div>
                <div className="flex items-center gap-2">
                  <div className={`w-2 h-2 rounded-full ${HOUSE_CONFIG[result.third].color === '#fbbf24' ? 'bg-amber-400' : HOUSE_CONFIG[result.third].color === '#60a5fa' ? 'bg-blue-400' : 'bg-rose-400'}`}></div>
                  <span className="font-bold text-slate-200">{result.third}</span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
