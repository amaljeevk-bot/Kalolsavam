
import React, { useMemo, useEffect, useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { HouseStats, HOUSE_CONFIG } from '../types';
import { getFestivalCommentary } from '../services/geminiService';
import { EventResult } from '../types';

interface DashboardProps {
  stats: HouseStats[];
  results: EventResult[];
}

export const Dashboard: React.FC<DashboardProps> = ({ stats, results }) => {
  const [commentary, setCommentary] = useState<string>("Analyzing current standings...");
  const [loadingCommentary, setLoadingCommentary] = useState(true);

  useEffect(() => {
    const fetchCommentary = async () => {
      setLoadingCommentary(true);
      const text = await getFestivalCommentary(stats, results);
      setCommentary(text || "Welcome to the YouthFest Result Portal!");
      setLoadingCommentary(false);
    };
    fetchCommentary();
  }, [stats, results]);

  const sortedStats = useMemo(() => [...stats].sort((a, b) => b.totalPoints - a.totalPoints), [stats]);
  const leadingHouse = sortedStats[0];

  return (
    <div className="space-y-8 animate-in fade-in duration-700">
      {/* Hero Section / AI Commentary */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-indigo-900/40 via-slate-900 to-slate-950 border border-indigo-500/20 p-8 shadow-2xl">
        <div className="absolute -top-24 -right-24 w-64 h-64 bg-indigo-600/10 blur-[100px] rounded-full"></div>
        <div className="relative z-10 flex flex-col md:flex-row items-center gap-8">
          <div className="flex-1 space-y-4">
            <span className="inline-block px-3 py-1 bg-indigo-500/20 text-indigo-400 text-xs font-bold tracking-widest uppercase rounded-full border border-indigo-500/30">
              Live AI Commentary
            </span>
            <p className="text-2xl md:text-3xl font-bold italic text-slate-100 leading-tight">
              "{loadingCommentary ? "Tuning into the stadium..." : commentary}"
            </p>
          </div>
          <div className="shrink-0 flex flex-col items-center">
            <div className="text-sm font-bold text-indigo-400 mb-2 uppercase tracking-tighter">Current Leader</div>
            <div className={`text-5xl font-black bg-gradient-to-br ${HOUSE_CONFIG[leadingHouse.name].gradient} bg-clip-text text-transparent drop-shadow-sm`}>
              {leadingHouse.totalPoints > 0 ? leadingHouse.name.toUpperCase() : "TBD"}
            </div>
            <div className="text-slate-500 text-sm mt-1">{leadingHouse.totalPoints} Points</div>
          </div>
        </div>
      </div>

      {/* House Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {sortedStats.map((house, index) => (
          <div 
            key={house.name} 
            className="group relative glass-morphism rounded-2xl p-6 transition-all duration-300 hover:translate-y-[-4px] hover:shadow-2xl hover:shadow-indigo-500/10 overflow-hidden"
          >
            {/* Rank Badge */}
            <div className="absolute top-4 right-4 w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center border border-slate-700 text-xs font-bold text-slate-400">
              #{index + 1}
            </div>

            <div className="flex flex-col h-full">
              <div className="flex items-center gap-4 mb-6">
                <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${HOUSE_CONFIG[house.name].gradient} flex items-center justify-center shadow-lg`}>
                  <span className="text-2xl font-black text-white">{house.name[0]}</span>
                </div>
                <div>
                  <h3 className="text-xl font-bold text-white">{house.name}</h3>
                  <div className="flex gap-2">
                    <span className="w-2 h-2 rounded-full bg-amber-400"></span>
                    <span className="w-2 h-2 rounded-full bg-slate-300"></span>
                    <span className="w-2 h-2 rounded-full bg-amber-700"></span>
                  </div>
                </div>
              </div>

              <div className="space-y-4 flex-grow">
                <div className="flex justify-between items-end">
                  <div className="text-4xl font-black text-white">{house.totalPoints}</div>
                  <div className="text-slate-500 text-sm mb-1 uppercase tracking-wider font-bold">Total Points</div>
                </div>
                
                <div className="grid grid-cols-3 gap-2 pt-4 border-t border-slate-800">
                  <div className="text-center">
                    <div className="text-amber-400 font-bold">{house.firstCount}</div>
                    <div className="text-[10px] text-slate-500 uppercase">1st</div>
                  </div>
                  <div className="text-center">
                    <div className="text-slate-300 font-bold">{house.secondCount}</div>
                    <div className="text-[10px] text-slate-500 uppercase">2nd</div>
                  </div>
                  <div className="text-center">
                    <div className="text-amber-700 font-bold">{house.thirdCount}</div>
                    <div className="text-[10px] text-slate-500 uppercase">3rd</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Chart Section */}
      <div className="glass-morphism rounded-3xl p-8 border border-slate-800">
        <h3 className="text-xl font-bold mb-8 text-white flex items-center gap-2">
          <span className="w-1.5 h-6 bg-indigo-500 rounded-full"></span>
          Points Distribution
        </h3>
        <div className="h-[300px] w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={stats}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#1e293b" />
              <XAxis dataKey="name" stroke="#64748b" fontSize={12} tickLine={false} axisLine={false} />
              <YAxis stroke="#64748b" fontSize={12} tickLine={false} axisLine={false} />
              <Tooltip 
                cursor={{fill: 'rgba(255,255,255,0.05)'}}
                contentStyle={{ backgroundColor: '#0f172a', border: '1px solid #1e293b', borderRadius: '12px' }}
                itemStyle={{ color: '#f8fafc' }}
              />
              <Bar dataKey="totalPoints" radius={[6, 6, 0, 0]}>
                {stats.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={HOUSE_CONFIG[entry.name].color} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};
