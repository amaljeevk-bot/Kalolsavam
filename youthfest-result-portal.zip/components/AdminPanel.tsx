
import React, { useState } from 'react';
import { HouseName, EventResult } from '../types';

interface AdminPanelProps {
  onAddResult: (result: Omit<EventResult, 'id' | 'timestamp'>) => void;
  onReset: () => void;
  results: EventResult[];
  onDeleteResult: (id: string) => void;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({ onAddResult, onReset, results, onDeleteResult }) => {
  const [eventName, setEventName] = useState('');
  const [category, setCategory] = useState<'Stage' | 'Non-Stage' | 'Sports'>('Stage');
  const [first, setFirst] = useState<HouseName>('Alpha');
  const [second, setSecond] = useState<HouseName>('Beta');
  const [third, setThird] = useState<HouseName>('Gamma');
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [password, setPassword] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (first === second || second === third || first === third) {
      alert("A house cannot win multiple positions in the same event!");
      return;
    }
    onAddResult({ eventName, category, first, second, third });
    setEventName('');
  };

  if (!isAuthenticated) {
    return (
      <div className="max-w-md mx-auto py-20 flex flex-col items-center">
        <div className="glass-morphism p-8 rounded-3xl w-full border border-slate-800 text-center">
          <div className="w-16 h-16 bg-indigo-500/20 rounded-2xl flex items-center justify-center mx-auto mb-6 text-indigo-400">
             <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
             </svg>
          </div>
          <h2 className="text-2xl font-bold mb-2">Admin Access</h2>
          <p className="text-slate-500 text-sm mb-6">Password is required to update results</p>
          <input
            type="password"
            placeholder="Enter Admin Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 mb-4"
          />
          <button
            onClick={() => password === 'admin' ? setIsAuthenticated(true) : alert('Wrong Password')}
            className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 rounded-xl transition-all shadow-lg shadow-indigo-500/20"
          >
            Authenticate
          </button>
          <p className="text-[10px] text-slate-600 mt-4 uppercase font-bold tracking-widest">Demo Password: admin</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8 max-w-4xl mx-auto">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-white">Result Management</h2>
        <button
          onClick={() => { if(confirm('Erase ALL data?')) onReset() }}
          className="bg-rose-500/10 hover:bg-rose-500/20 text-rose-500 text-xs font-bold px-4 py-2 rounded-lg border border-rose-500/20 transition-all"
        >
          Reset All Points
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="md:col-span-2 glass-morphism p-8 rounded-3xl border border-slate-800">
          <h3 className="text-lg font-bold mb-6 text-indigo-400">Add New Result</h3>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-500 mb-2 uppercase">Event Name</label>
                <input
                  type="text"
                  required
                  value={eventName}
                  onChange={(e) => setEventName(e.target.value)}
                  placeholder="e.g. Classical Dance"
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-2.5 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-500 mb-2 uppercase">Category</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value as any)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-2.5 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="Stage">Stage Events</option>
                  <option value="Non-Stage">Non-Stage Events</option>
                  <option value="Sports">Sports</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-500 mb-2 uppercase">1st Place</label>
                <select
                  value={first}
                  onChange={(e) => setFirst(e.target.value as HouseName)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-2 text-sm text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="Alpha">Alpha</option>
                  <option value="Beta">Beta</option>
                  <option value="Gamma">Gamma</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-500 mb-2 uppercase">2nd Place</label>
                <select
                  value={second}
                  onChange={(e) => setSecond(e.target.value as HouseName)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-2 text-sm text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="Alpha">Alpha</option>
                  <option value="Beta">Beta</option>
                  <option value="Gamma">Gamma</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-500 mb-2 uppercase">3rd Place</label>
                <select
                  value={third}
                  onChange={(e) => setThird(e.target.value as HouseName)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-2 text-sm text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="Alpha">Alpha</option>
                  <option value="Beta">Beta</option>
                  <option value="Gamma">Gamma</option>
                </select>
              </div>
            </div>

            <button
              type="submit"
              className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 rounded-xl transition-all shadow-lg shadow-indigo-500/20"
            >
              Publish Result
            </button>
          </form>
        </div>

        <div className="glass-morphism rounded-3xl p-6 border border-slate-800 overflow-hidden flex flex-col">
          <h3 className="text-lg font-bold mb-4 text-slate-300">Quick Actions</h3>
          <div className="space-y-3 overflow-y-auto max-h-[400px]">
            {results.length === 0 ? (
              <p className="text-slate-600 text-sm italic">No entries yet</p>
            ) : (
              results.map(r => (
                <div key={r.id} className="flex justify-between items-center p-3 bg-slate-900/50 rounded-xl border border-slate-800 group">
                  <div className="overflow-hidden">
                    <p className="text-sm font-bold truncate text-slate-300">{r.eventName}</p>
                    <p className="text-[10px] text-slate-500">{new Date(r.timestamp).toLocaleDateString()}</p>
                  </div>
                  <button
                    onClick={() => onDeleteResult(r.id)}
                    className="p-2 opacity-0 group-hover:opacity-100 text-rose-400 hover:bg-rose-500/10 rounded-lg transition-all"
                  >
                    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                    </svg>
                  </button>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
